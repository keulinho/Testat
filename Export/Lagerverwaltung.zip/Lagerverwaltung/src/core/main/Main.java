package core.main;

import controller.LagerVerwaltungsController;
/**@author Marius Mamsch
**/
public class Main {

	public static void main(String[] args) {
		LagerVerwaltungsController control = new LagerVerwaltungsController();
	}

}
